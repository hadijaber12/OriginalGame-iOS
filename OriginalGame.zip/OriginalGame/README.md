# Original Game Starter

This is a standalone Unity starter project. It does not contain code or assets from the previously open app bundle.

## Open and run

Open this folder in Unity 6.0 or newer, open `Assets/Scenes/Main.unity`, and press Play. The debug store is visible in the Editor and in Development Builds.

## Local mock billing

The debug catalog contains three sample products, each displayed at exactly `1 ر.س` (`100` halalas, currency code `SAR`). Selecting a product immediately records a simulated local unlock in `PlayerPrefs`; the store makes no payment, network, Apple StoreKit, Unity IAP, or TestFlight calls. Use **Reset local test purchases** to clear the saved test state.

The mock billing provider is compiled only for the Unity Editor and Development Builds. A non-development release build contains an inert component and does not include the mock provider or its purchase logic. These test prices and local unlocks are not real prices, receipts, or production entitlements.