#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;
using System.Collections.Generic;
using UnityEngine;

namespace OriginalGame.Billing
{
    public sealed class MockProduct
    {
        public string Id { get; private set; }
        public string Name { get; private set; }
        public int PriceInHalalas { get; private set; }
        public string CurrencyCode { get; private set; }
        public string DisplayPrice { get; private set; }

        public MockProduct(string id, string name)
        {
            Id = id;
            Name = name;
            PriceInHalalas = 100;
            CurrencyCode = "SAR";
            DisplayPrice = "1 ر.س";
        }
    }

    public sealed class MockPurchaseResult
    {
        public bool Success { get; private set; }
        public bool NewTransaction { get; private set; }
        public string ProductId { get; private set; }
        public string TransactionId { get; private set; }
        public string Message { get; private set; }

        public MockPurchaseResult(bool success, bool newTransaction, string productId, string transactionId, string message)
        {
            Success = success;
            NewTransaction = newTransaction;
            ProductId = productId;
            TransactionId = transactionId;
            Message = message;
        }
    }

    [Serializable]
    internal sealed class OwnedProductsData
    {
        public List<string> productIds = new List<string>();
    }

    public sealed class MockBillingProvider
    {
        private const string StorageKey = "original_game.debug_mock_billing.owned_products";

        private static readonly IReadOnlyList<MockProduct> ProductCatalog = Array.AsReadOnly(new[]
        {
            new MockProduct("gems_small", "Small Gem Pack"),
            new MockProduct("gems_large", "Large Gem Pack"),
            new MockProduct("starter_bundle", "Starter Bundle")
        });

        private readonly HashSet<string> ownedProductIds;

        public IReadOnlyList<MockProduct> Products { get { return ProductCatalog; } }

        public MockBillingProvider()
        {
            ownedProductIds = LoadOwnedProducts();
        }

        public bool IsOwned(string productId)
        {
            return ownedProductIds.Contains(productId);
        }

        public MockPurchaseResult Purchase(string productId)
        {
            MockProduct product = FindProduct(productId);
            if (product == null)
            {
                return new MockPurchaseResult(false, false, productId, null, "Unknown test product.");
            }

            if (!ownedProductIds.Add(productId))
            {
                return new MockPurchaseResult(true, false, productId, null, "Already unlocked in local test data.");
            }

            SaveOwnedProducts();
            return new MockPurchaseResult(true, true, productId, Guid.NewGuid().ToString("N"), "Simulated locally; no payment was made.");
        }

        public void ClearLocalPurchases()
        {
            ownedProductIds.Clear();
            PlayerPrefs.DeleteKey(StorageKey);
            PlayerPrefs.Save();
        }

        private static MockProduct FindProduct(string productId)
        {
            for (int index = 0; index < ProductCatalog.Count; index++)
            {
                if (ProductCatalog[index].Id == productId)
                {
                    return ProductCatalog[index];
                }
            }

            return null;
        }

        private static HashSet<string> LoadOwnedProducts()
        {
            HashSet<string> result = new HashSet<string>();
            string json = PlayerPrefs.GetString(StorageKey, string.Empty);
            if (string.IsNullOrEmpty(json))
            {
                return result;
            }

            OwnedProductsData data = JsonUtility.FromJson<OwnedProductsData>(json);
            if (data != null && data.productIds != null)
            {
                for (int index = 0; index < data.productIds.Count; index++)
                {
                    if (FindProduct(data.productIds[index]) != null)
                    {
                        result.Add(data.productIds[index]);
                    }
                }
            }

            return result;
        }

        private void SaveOwnedProducts()
        {
            OwnedProductsData data = new OwnedProductsData();
            data.productIds.AddRange(ownedProductIds);
            PlayerPrefs.SetString(StorageKey, JsonUtility.ToJson(data));
            PlayerPrefs.Save();
        }
    }
}
#endif