#if UNITY_EDITOR || DEVELOPMENT_BUILD
using OriginalGame.Billing;
using UnityEngine;

public sealed class DebugMockStore : MonoBehaviour
{
    private MockBillingProvider billingProvider;
    private string status = "Local test store ready. No payment will be made.";

    private void Awake()
    {
        billingProvider = new MockBillingProvider();
    }

    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(20, 20, 380, Screen.height - 40), GUI.skin.box);
        GUILayout.Label("Original Game | Debug Store");
        GUILayout.Label("Test prices: 1 ر.س each");
        GUILayout.Space(8);

        foreach (MockProduct product in billingProvider.Products)
        {
            string buttonLabel = billingProvider.IsOwned(product.Id)
                ? product.Name + " - Unlocked locally"
                : product.Name + " - " + product.DisplayPrice;

            if (GUILayout.Button(buttonLabel, GUILayout.Height(36)) && !billingProvider.IsOwned(product.Id))
            {
                MockPurchaseResult result = billingProvider.Purchase(product.Id);
                status = result.Message;
            }
        }

        GUILayout.Space(8);
        GUILayout.Label(status);
        if (GUILayout.Button("Reset local test purchases"))
        {
            billingProvider.ClearLocalPurchases();
            status = "Local test data cleared.";
        }

        GUILayout.EndArea();
    }
}
#else
using UnityEngine;

public sealed class DebugMockStore : MonoBehaviour
{
}
#endif